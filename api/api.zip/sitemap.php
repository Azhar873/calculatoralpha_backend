<?php
/**
 * Public Sitemap API
 * GET /api/sitemap
 */

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    sendResponse(['error' => 'Method not allowed'], 405);
}

$stmt = $pdo->query('SELECT id, url_type, source_id, slug, url, lastmod, changefreq, priority FROM sitemap ORDER BY id ASC');
$entries = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (($_GET['format'] ?? '') === 'xml') {
    header('Content-Type: application/xml; charset=UTF-8');
    $xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
    $xml .= "<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n";
    foreach ($entries as $entry) {
        $xml .= "  <url>\n";
        $xml .= "    <loc>" . htmlspecialchars($entry['url'], ENT_XML1) . "</loc>\n";
        $xml .= "    <lastmod>" . htmlspecialchars($entry['lastmod'], ENT_XML1) . "</lastmod>\n";
        $xml .= "    <changefreq>" . htmlspecialchars($entry['changefreq'], ENT_XML1) . "</changefreq>\n";
        $xml .= "    <priority>" . htmlspecialchars($entry['priority'], ENT_XML1) . "</priority>\n";
        $xml .= "  </url>\n";
    }
    $xml .= "</urlset>\n";
    echo $xml;
    exit;
}

sendResponse($entries);